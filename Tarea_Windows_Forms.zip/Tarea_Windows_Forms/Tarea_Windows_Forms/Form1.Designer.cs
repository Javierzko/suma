﻿namespace Tarea_Windows_Forms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txt1 = new TextBox();
            txt2 = new TextBox();
            txt3r = new TextBox();
            label4 = new Label();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Emoji", 12F);
            button1.Location = new Point(262, 172);
            button1.Name = "button1";
            button1.Size = new Size(105, 33);
            button1.TabIndex = 0;
            button1.Text = "sumar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 12F);
            label1.Location = new Point(183, 89);
            label1.Name = "label1";
            label1.Size = new Size(54, 21);
            label1.TabIndex = 1;
            label1.Text = "dato 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 12F);
            label2.Location = new Point(179, 134);
            label2.Name = "label2";
            label2.Size = new Size(54, 21);
            label2.TabIndex = 2;
            label2.Text = "dato 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 12F);
            label3.Location = new Point(154, 224);
            label3.Name = "label3";
            label3.Size = new Size(79, 21);
            label3.TabIndex = 3;
            label3.Text = "Resultado";
            // 
            // txt1
            // 
            txt1.Font = new Font("Segoe UI Emoji", 12F);
            txt1.Location = new Point(262, 86);
            txt1.Name = "txt1";
            txt1.Size = new Size(105, 29);
            txt1.TabIndex = 4;
            // 
            // txt2
            // 
            txt2.Font = new Font("Segoe UI Emoji", 12F);
            txt2.Location = new Point(262, 131);
            txt2.Name = "txt2";
            txt2.Size = new Size(105, 29);
            txt2.TabIndex = 5;
            // 
            // txt3r
            // 
            txt3r.Font = new Font("Segoe UI Emoji", 12F);
            txt3r.Location = new Point(239, 224);
            txt3r.Name = "txt3r";
            txt3r.Size = new Size(144, 29);
            txt3r.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe Print", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(130, 21);
            label4.Name = "label4";
            label4.Size = new Size(361, 43);
            label4.TabIndex = 7;
            label4.Text = "Tarea_suma de dos numeros";
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Emoji", 12F);
            button2.Location = new Point(398, 173);
            button2.Name = "button2";
            button2.Size = new Size(75, 32);
            button2.TabIndex = 8;
            button2.Text = "Salir";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI Emoji", 12F);
            button3.Location = new Point(162, 172);
            button3.Name = "button3";
            button3.Size = new Size(75, 33);
            button3.TabIndex = 9;
            button3.Text = "Limpiar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label4);
            Controls.Add(txt3r);
            Controls.Add(txt2);
            Controls.Add(txt1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "sumar";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txt1;
        private TextBox txt2;
        private TextBox txt3r;
        private Label label4;
        private Button button2;
        private Button button3;
    }
}
