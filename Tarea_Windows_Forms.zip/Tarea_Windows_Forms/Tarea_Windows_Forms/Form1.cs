namespace Tarea_Windows_Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            txt1.Text = " ";
            txt2.Text = " ";
            txt3r.Text = "";


        }

        private void button1_Click(object sender, EventArgs e)
        {
            double N1, N2, R;
            N1 = double.Parse(txt1.Text);
            N2 = double.Parse(txt2.Text);
            R = N1 + N2;
            txt3r.Text = R.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
